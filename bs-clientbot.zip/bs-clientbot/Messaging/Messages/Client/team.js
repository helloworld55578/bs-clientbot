var ByteStream = require("../../../DataStream/ByteStream");

module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    encode(l) {
        this.ByteStream.writeVInt(0);
        this.ByteStream.writeVInt(l);
        
    }
}
