var ByteStream = require("../../../DataStream/ByteStream");

module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    encode(name) {
        this.ByteStream.writeString("ig:/efee2015_");
        this.ByteStream.writeVInt(1);
        
    }
}
